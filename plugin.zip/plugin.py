"""
Network Discovery plugin for Jen.
Scans subnets for devices and says what each one IS, using everything
Jen already knows, before calling anything "unknown".
Requires nmap on the Jen host — Settings → Plugins can install it (Jen
5.30.0+, systemd hosts); elsewhere `sudo apt install nmap`.
Version lives in manifest.json — not duplicated here.

How a scan finds hosts (v1.0.3)
────────────────────────────────
Jen runs as an unprivileged service user, so nmap can't send raw
packets: `nmap -sn` degrades to TCP connect() probes against a handful
of common ports, and reports no MAC addresses at all. Two consequences,
and how they're handled:

  * On a subnet the Jen host is directly attached to, every one of
    those connect() attempts makes the kernel ARP for the target first
    — and every host that exists answers ARP whether or not it answers
    TCP. So right after the sweep, the kernel neighbour table holds a
    fresh (REACHABLE) entry, with MAC, for every live host on that
    link. `_neighbour_table()` reads it: REACHABLE entries inside the
    CIDR are added as found hosts even when nmap saw nothing, and any
    non-failed entry supplies the MAC for a host nmap did see.
  * On a routed subnet there are no neighbour entries for it, so only
    hosts answering one of the probed ports are found, without MACs.

What a found host is (v1.1.0)
─────────────────────────────
Each host gets ONE status, first match wins:

  lease           an active Kea lease (by IP, or by MAC)
  reservation     a Kea host reservation — this subnet's or a global one
  infrastructure  the gateway, a DNS server, the Kea server, the Jen
                  host, network/broadcast — from Jen's subnet_context
  ipam            an IPAM Lite static/planned entry (by IP or MAC),
                  when that plugin is installed
  device          a device Jen has seen before (the devices table, by
                  MAC) that has no lease right now — a static host
  known           an address/MAC the operator marked "I know this one"
  unknown         nothing above — the only status that alerts

The old `in_kea` / `rogue` columns are kept and derived (rogue means
unknown) so nothing that read them breaks.
"""

import contextlib
import csv
import io
import ipaddress
import logging
import os as _os
import shutil
import subprocess
import threading
from datetime import datetime, timedelta, timezone

from flask import Blueprint, flash, jsonify, make_response, redirect, render_template, request, url_for
from flask_login import current_user, login_required

logger = logging.getLogger(__name__)

PLUGIN_ID = "network-discovery"

bp = Blueprint(
    "network_discovery",
    __name__,
    template_folder="templates",
    root_path=_os.path.dirname(_os.path.abspath(__file__)),
    url_prefix="/network/discovery",
)

_scan_lock = threading.Lock()

# How many scan jobs (and their results) to keep per subnet, newest first. The newest COMPLETED scan
# is kept whatever its age (see jobs_to_prune): it is the baseline the next scan's "new unknown" alert
# and the results page's "what changed" both compare against.
_KEEP_JOBS = 3


# Job ids whose scan is queued or running in THIS process. A queued job's thread may wait a long time
# behind other scans for _scan_lock (three /20 scans in front of it is more than the stale window), and a
# row that is only waiting must not be expired: the duplicate check would then queue a second scan of the
# same subnet. After a Jen restart the set is empty, so a leftover row still expires.
_live_jobs = set()

# A job still 'running' after this long is a leftover from a Jen restart
# (the scan thread died with the process) — nothing will ever finish it.
_STALE_RUNNING_MINUTES = 30

# nmap's unprivileged -sn is a TCP connect() sweep; widening it past the
# default 80/443 catches printers (9100), Windows (445/3389), SSH boxes
# and the usual web-UI ports on routed subnets where ARP can't help.
_NMAP_PROBE_PORTS = "22,80,443,445,3389,8080,8443,9100"

# v1.1.0 — scope and time. Anything larger than a /20 (4,094 hosts) is
# refused outright rather than timing out into a bare error; the timeout
# scales with the address count.
_MAX_SCAN_PREFIX = 20
_TIMEOUT_BASE_S = 60
_TIMEOUT_PER_HOST_S = 0.125
_TIMEOUT_CAP_S = 900

# Neighbour-table states that mean "the kernel just heard from this MAC".
# STALE is deliberately NOT here for adding hosts — a STALE entry can
# outlive the device by hours — but it still supplies a MAC for a host
# nmap independently confirmed is up.
_NEIGH_FRESH = {"REACHABLE", "DELAY", "PROBE", "PERMANENT"}
_NEIGH_DEAD = {"FAILED", "INCOMPLETE", "NONE"}

_STATUSES = ("lease", "reservation", "infrastructure", "ipam", "device", "known", "unknown")
# v1.2.0 — split from a combined "glyph + text" string into an icon name
# (a sprite via Jen's icon() Jinja global) and plain label text, so the
# templates render a real icon instead of a bare emoji character.
_STATUS_LABELS = {
    "lease": "Kea lease",
    "reservation": "Kea reservation",
    "infrastructure": "Infrastructure",
    "ipam": "IPAM entry",
    "device": "Known device",
    "known": "Marked known",
    "unknown": "Unknown",
}
_STATUS_ICONS = {
    "lease": "circle-check",
    "reservation": "circle-check",
    "infrastructure": "server",
    "ipam": "clipboard-list",
    "device": "monitor-smartphone",
    "known": "circle-check",
    "unknown": "triangle-alert",
}
_INFRA_LABELS = {
    "gateway": "Gateway",
    "dns": "DNS server",
    "kea-server": "Kea server",
    "jen-host": "Jen host",
    "network": "Network",
    "broadcast": "Broadcast",
}

# Scheduled scans (v1.1.0): the periodic hook ticks this often and runs
# whatever subnets are due; the per-subnet interval is in nd_settings.
_SCHEDULE_TICK_MINUTES = 30
_SCHEDULE_CHOICES = (0, 6, 12, 24, 168)


# ── Helpers ───────────────────────────────────────────────────────────────────


def _get_db():
    from jen.plugin_api import get_jen_db

    return get_jen_db()


def _get_kea_db():
    from jen.plugin_api import get_kea_db

    return get_kea_db()


def _subnet_map():
    from jen.plugin_api import subnet_map

    return subnet_map()


def _accessible_subnets():
    from jen.plugin_api import get_accessible_subnet_map

    return get_accessible_subnet_map()


def _is_superadmin():
    return getattr(current_user, "role", "") == "superadmin"


def _is_admin():
    try:
        from jen.plugin_api import is_admin_or_above

        return is_admin_or_above()
    except Exception:
        # Fall back to a direct role check if the import shape ever changes.
        role = getattr(current_user, "role", None)
        if role is not None:
            return role in ("superadmin", "admin")
        return bool(getattr(current_user, "is_admin", False))


def _require_write():
    """v1.1.2 — start_scan and mark_known used to gate only on
    assert_subnet_access, never the role: a read-only viewer could launch
    an nmap sweep from the Jen host, or add/forget a nd_known_hosts row and
    silence (or un-silence) a rogue_device alert for a MAC seen anywhere.
    Every write route calls this FIRST, before assert_subnet_access and
    before touching request.form."""
    if _is_admin():
        return True
    flash("Viewers can look at Discovery but not scan or mark hosts.", "error")
    return False


def _can_change_known():
    """The known-hosts list decides which hosts count as unknown and so alert, and it has no subnet
    column: a mark or a forget applies to that MAC or IP on EVERY subnet. Authorising it on the one
    subnet in the URL let an admin scoped to subnet A silence, or re-arm, the alert for subnet B's
    hosts. It is an all-subnets object, like an IPAM unmanaged subnet: an admin who can see every subnet."""
    return _is_admin() and bool(getattr(current_user, "all_subnets", False))


def _nmap_available():
    return shutil.which("nmap") is not None


def _can_install_nmap():
    """Jen 5.30.0's plugin os_packages path exists and this is a systemd
    host (the root-run plugin service can apt-install nmap)."""
    try:
        from jen.plugin_api import is_systemd_host

        return bool(is_systemd_host())
    except Exception:
        return False


def _ip_binary():
    """`ip` lives in /usr/sbin, which a service user's PATH may not have."""
    for candidate in ("ip", "/usr/sbin/ip", "/sbin/ip", "/bin/ip"):
        found = (
            shutil.which(candidate)
            if "/" not in candidate
            else (candidate if _os.access(candidate, _os.X_OK) else None)
        )
        if found:
            return found
    return None


def _safe_row(values):
    try:
        from jen.plugin_api import safe_row

        return safe_row(values)
    except Exception:
        out = []
        for v in values:
            s = "" if v is None else str(v)
            out.append(f"'{s}" if s and s[0] in ("=", "+", "-", "@", "\t", "\r") else s)
        return out


def _hex_to_mac(hex_str):
    return ":".join(hex_str[i : i + 2] for i in range(0, 12, 2)).lower()


# ── Scanning ──────────────────────────────────────────────────────────────────


def scan_timeout_for(network):
    """Seconds nmap gets for this subnet: a floor plus a per-host share,
    capped. A /24 gets ~92 s, a /20 the cap."""
    return int(min(_TIMEOUT_CAP_S, _TIMEOUT_BASE_S + network.num_addresses * _TIMEOUT_PER_HOST_S))


def scan_scope_error(cidr):
    """Why a subnet can't be scanned, or None."""
    try:
        network = ipaddress.IPv4Network(cidr, strict=False)
    except ValueError:
        return f"Invalid subnet CIDR: {cidr}"
    if network.prefixlen < _MAX_SCAN_PREFIX:
        return (
            f"{cidr} is larger than a /{_MAX_SCAN_PREFIX} ({network.num_addresses:,} addresses) — an unprivileged "
            "connect() sweep of that many hosts takes far too long; scan a smaller subnet."
        )
    return None


def _parse_nmap_greppable(text):
    """`nmap -sn --oG -` → [{ip, mac, hostname}]. Only up hosts are listed
    in greppable output for a ping scan; each is `Host: <ip> (<name>)`."""
    hosts = []
    for line in text.splitlines():
        if not line.startswith("Host:"):
            continue
        parts = line.split()
        ip = parts[1] if len(parts) > 1 else ""
        try:
            ipaddress.IPv4Address(ip)
        except ValueError:
            continue
        hostname = ""
        if len(parts) > 2 and parts[2].startswith("("):
            h = parts[2].strip("()")
            hostname = h if h and h != ip else ""
        hosts.append({"ip": ip, "mac": "", "hostname": hostname})
    return hosts


def _parse_neighbours(text, network):
    """`ip -4 neigh show` → {ip: (mac, state)} for entries inside `network`
    that have a MAC and aren't dead. Lines look like
    `10.0.0.5 dev eth0 lladdr aa:bb:cc:dd:ee:ff REACHABLE`."""
    out = {}
    for line in text.splitlines():
        parts = line.split()
        if not parts:
            continue
        try:
            addr = ipaddress.IPv4Address(parts[0])
        except ValueError:
            continue
        if addr not in network:
            continue
        mac = ""
        if "lladdr" in parts:
            i = parts.index("lladdr")
            if i + 1 < len(parts):
                mac = parts[i + 1].lower()
        state = parts[-1].upper() if parts else ""
        if not mac or state in _NEIGH_DEAD:
            continue
        out[str(addr)] = (mac, state)
    return out


def _neighbour_table(network):
    """Best effort — an empty dict on any failure (no `ip`, Docker with no
    view of the host's links, a routed subnet with no entries)."""
    ip_bin = _ip_binary()
    if not ip_bin:
        return {}
    try:
        result = subprocess.run([ip_bin, "-4", "neigh", "show"], capture_output=True, text=True, timeout=10)
    except Exception as e:
        logger.warning(f"Network Discovery: could not read the neighbour table: {e}")
        return {}
    if result.returncode != 0:
        return {}
    return _parse_neighbours(result.stdout, network)


def _merge_neighbours(hosts, neighbours):
    """Attach MACs from the neighbour table to hosts nmap found, and add
    hosts the kernel just heard from that nmap missed (no open probe
    port). Pure; see the module docstring for why this is sound."""
    by_ip = {h["ip"]: h for h in hosts}
    for ip, (mac, state) in neighbours.items():
        if ip in by_ip:
            if not by_ip[ip]["mac"]:
                by_ip[ip]["mac"] = mac
        elif state in _NEIGH_FRESH:
            by_ip[ip] = {"ip": ip, "mac": mac, "hostname": ""}
    return sorted(by_ip.values(), key=lambda h: int(ipaddress.IPv4Address(h["ip"])))


def _scan_subnet(cidr):
    """Scan a subnet with nmap, enriched from the neighbour table.
    Returns {"hosts": [{ip, mac, hostname}]} or {"error": str}."""
    if not _nmap_available():
        return {"error": "nmap is not installed on the Jen host"}
    scope = scan_scope_error(cidr)
    if scope:
        return {"error": scope}
    network = ipaddress.IPv4Network(cidr, strict=False)
    timeout = scan_timeout_for(network)
    try:
        result = subprocess.run(
            ["nmap", "-sn", "-T4", "--host-timeout", "5s", "-PS" + _NMAP_PROBE_PORTS, cidr, "--oG", "-"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return {"error": f"nmap did not finish within {timeout}s"}
    except Exception as e:
        logger.error(f"Network Discovery: nmap failed: {e}")
        return {"error": "nmap could not be run — see the Jen log"}
    if result.returncode != 0:
        detail = (result.stderr or "").strip().splitlines()
        logger.error(f"Network Discovery: nmap exited {result.returncode}: {detail[-1] if detail else ''}")
        return {"error": f"nmap exited with status {result.returncode} — see the Jen log"}

    hosts = _parse_nmap_greppable(result.stdout)
    return {"hosts": _merge_neighbours(hosts, _neighbour_table(network))}


# ── What Jen knows ────────────────────────────────────────────────────────────


def _subnet_ctx(subnet_id, cidr):
    """Jen's subnet_context (5.30.0) — gateway, DNS, Kea/Jen hosts — else
    just network/broadcast."""
    try:
        from jen.plugin_api import subnet_context

        ctx = subnet_context(subnet_id)
        if ctx:
            return ctx
    except Exception as e:
        logger.warning(f"Network Discovery: subnet_context unavailable: {e}")
    infra = {}
    try:
        network = ipaddress.IPv4Network(cidr, strict=False)
        if network.prefixlen < 31:
            infra[str(network.network_address)] = "network"
            infra[str(network.broadcast_address)] = "broadcast"
    except ValueError:
        pass
    return {"infrastructure": infra, "gateways": [], "dns": [], "pools": []}


def _load_kea(subnet_id):
    """(lease_ips, lease_macs, res_ips, res_macs) — reservations include
    global ones (dhcp4_subnet_id 0/NULL), which the old code missed.
    Only a type-0 (hw-address) identifier is a MAC."""
    lease_ips, lease_macs, res_ips, res_macs = set(), set(), set(), set()
    kdb = None
    try:
        kdb = _get_kea_db()
        with kdb.cursor() as cur:
            cur.execute(
                "SELECT inet_ntoa(address) AS ip, HEX(hwaddr) AS mac_hex FROM lease4 WHERE state=0 AND subnet_id=%s",
                (subnet_id,),
            )
            for row in cur.fetchall():
                if row["ip"]:
                    lease_ips.add(row["ip"])
                if row.get("mac_hex") and len(row["mac_hex"]) == 12:
                    lease_macs.add(_hex_to_mac(row["mac_hex"]))
            cur.execute(
                "SELECT inet_ntoa(ipv4_address) AS ip, HEX(dhcp_identifier) AS ident_hex, "
                "dhcp_identifier_type AS ident_type FROM hosts "
                "WHERE dhcp4_subnet_id=%s OR dhcp4_subnet_id=0 OR dhcp4_subnet_id IS NULL",
                (subnet_id,),
            )
            for row in cur.fetchall():
                if row["ip"]:
                    res_ips.add(row["ip"])
                if row.get("ident_hex") and row.get("ident_type") == 0 and len(row["ident_hex"]) == 12:
                    res_macs.add(_hex_to_mac(row["ident_hex"]))
    except Exception as e:
        logger.error(f"Network Discovery: Kea cross-reference error: {e}")
    finally:
        if kdb:
            kdb.close()
    return lease_ips, lease_macs, res_ips, res_macs


def _load_ipam(subnet_id):
    """(ips, macs) of IPAM Lite static/planned entries for this subnet —
    read directly from its table when the plugin is installed; ({} , {})
    when it isn't (the table doesn't exist)."""
    ips, macs = {}, {}
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                "SELECT ip, mac, label, entry_status FROM ipam_static_entries "
                "WHERE subnet_kind='kea' AND subnet_id=%s AND entry_status IN ('static','planned')",
                (subnet_id,),
            )
            for row in cur.fetchall():
                label = row.get("label") or ""
                ips[row["ip"]] = label
                if row.get("mac"):
                    macs[row["mac"].lower()] = label
    except Exception:
        pass  # IPAM Lite not installed, or its table not yet migrated
    finally:
        if db:
            db.close()
    return ips, macs


def _load_devices(macs):
    """{mac: {name, owner, manufacturer, device_type, icon}} from Jen's
    devices table. One fixed statement per MAC."""
    out = {}
    macs = [m for m in macs if m]
    if not macs:
        return out
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            for mac in macs:
                cur.execute(
                    "SELECT device_name, owner, manufacturer, manufacturer_override, device_type, "
                    "device_type_override, device_icon, device_icon_override FROM devices WHERE mac=%s",
                    (mac,),
                )
                row = cur.fetchone()
                if row:
                    out[mac] = {
                        "name": row.get("device_name") or "",
                        "owner": row.get("owner") or "",
                        "manufacturer": row.get("manufacturer_override") or row.get("manufacturer") or "",
                        "device_type": row.get("device_type_override") or row.get("device_type") or "",
                        "icon": row.get("device_icon_override") or row.get("device_icon") or "",
                    }
    except Exception as e:
        logger.warning(f"Network Discovery: devices lookup failed: {e}")
    finally:
        if db:
            db.close()
    return out


def apply_known(rows, known):
    """Pure: re-derive 'known' vs 'unknown' on already-scanned rows from the CURRENT known-hosts list.

    v1.2.3 (Q100 a) — marking (or forgetting) a host used to UPDATE the one subnet's latest DONE job's
    stored rows; the known list has no subnet (`_can_change_known` already requires an administrator
    who sees every subnet to change it), so a host marked known from subnet A stayed 'unknown'/rogue on
    subnet B's results, index card, export and search until B happened to be rescanned. Every reader of
    scanned rows now re-derives 'known'/'unknown' from the list as it stands right now instead of trusting
    what a past scan (or a past mark_known UPDATE) wrote; every other status (a lease, a reservation, an
    infrastructure address, an IPAM entry, a device) is untouched, since the known list has no say over
    those. `known` is `_load_known()`'s own `{(mac, ip): note}` shape — a MAC-keyed host is looked up by
    MAC alone (mac takes precedence over ip, the same rule `mark_known` itself applies when saving)."""
    out = []
    for row in rows:
        row = dict(row)
        if row.get("status") in ("known", "unknown"):
            key = (row.get("mac") or "", "") if row.get("mac") else ("", row.get("ip") or "")
            note = known.get(key)
            if note is not None:
                row["status"], row["rogue"], row["label"] = "known", False, (note or row.get("label") or "")
            else:
                row["status"], row["rogue"] = "unknown", True
        out.append(row)
    return out


def _load_known():
    """{(mac or '', ip or ''): note} — the operator's "I know this one" list."""
    out = {}
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute("SELECT mac, ip, note FROM nd_known_hosts")
            for row in cur.fetchall():
                out[((row.get("mac") or "").lower(), row.get("ip") or "")] = row.get("note") or ""
    except Exception as e:
        logger.warning(f"Network Discovery: known-hosts read failed: {e}")
    finally:
        if db:
            db.close()
    return out


def _vendor(mac, hostname):
    """(manufacturer, device_type, icon) from Jen's OUI table; blanks when
    there's no MAC or the module isn't there."""
    if not mac:
        return "", "", ""
    try:
        from jen.plugin_api import classify_device

        manufacturer, device_type, icon = classify_device(mac, hostname or "")
        return (
            (manufacturer if manufacturer != "Unknown" else ""),
            (device_type if device_type != "unknown" else ""),
            icon,
        )
    except Exception:
        return "", "", ""


def classify(hosts, kea, ctx, ipam, devices, known):
    """Pure. `kea` = (lease_ips, lease_macs, res_ips, res_macs); `ipam` =
    (ips, macs) → label; `devices` by MAC; `known` {(mac, ip): note}.
    Returns the hosts with status / label / vendor fields; first match
    wins in _STATUSES order."""
    lease_ips, lease_macs, res_ips, res_macs = kea
    ipam_ips, ipam_macs = ipam
    infra = ctx.get("infrastructure", {})
    out = []
    for h in hosts:
        ip, mac = h["ip"], (h.get("mac") or "").lower()
        hostname = h.get("hostname") or ""
        label = ""
        if ip in lease_ips or (mac and mac in lease_macs):
            status = "lease"
        elif ip in res_ips or (mac and mac in res_macs):
            status = "reservation"
        elif ip in infra:
            status = "infrastructure"
            label = _INFRA_LABELS.get(infra[ip], infra[ip])
        elif ip in ipam_ips or (mac and mac in ipam_macs):
            status = "ipam"
            label = ipam_ips.get(ip) or ipam_macs.get(mac, "")
        elif mac and mac in devices:
            status = "device"
            label = devices[mac].get("name") or ""
        elif (mac, "") in known or ("", ip) in known or (mac, ip) in known:
            status = "known"
            label = known.get((mac, "")) or known.get(("", ip)) or known.get((mac, ip)) or ""
        else:
            status = "unknown"
        manufacturer, device_type, icon = _vendor(mac, hostname)
        dev = devices.get(mac) if mac else None
        if dev:
            manufacturer = dev.get("manufacturer") or manufacturer
            device_type = dev.get("device_type") or device_type
            icon = dev.get("icon") or icon
            if not label and status in ("lease", "reservation"):
                label = dev.get("name") or ""
        out.append(
            {
                **h,
                "mac": mac,
                "status": status,
                "label": label,
                "vendor": manufacturer,
                "device_type": device_type,
                "icon": icon,
                "in_kea": status in ("lease", "reservation"),
                "rogue": status == "unknown",
            }
        )
    return out


def host_key(h):
    """What identifies a host across scans: its MAC when known, else IP."""
    return ("mac", h["mac"]) if h.get("mac") else ("ip", h["ip"])


def new_unknowns(current, previous_keys):
    """Pure: the unknown hosts of `current` whose key the previous scan
    didn't already report as unknown. `previous_keys` None = no previous
    scan → everything unknown is new."""
    unknown = [h for h in current if h["status"] == "unknown"]
    if previous_keys is None:
        return unknown
    return [h for h in unknown if host_key(h) not in previous_keys]


def delta(current, previous):
    """Pure: ({key: host} appeared, {key: host} gone) between two result
    lists, keyed by MAC when known else IP."""
    cur = {host_key(h): h for h in current}
    prev = {host_key(h): h for h in previous}
    appeared = [cur[k] for k in cur if k not in prev]
    gone = [prev[k] for k in prev if k not in cur]
    return appeared, gone


# ── Jobs ──────────────────────────────────────────────────────────────────────


def _previous_results(cur, subnet_id, current_job_id):
    """The rows of the most recent completed scan of this subnet before
    the current one, or None when there wasn't one."""
    cur.execute(
        "SELECT id FROM nd_scan_jobs WHERE subnet_id=%s AND id != %s AND status='done' "
        "ORDER BY started_at DESC, id DESC LIMIT 1",
        (subnet_id, current_job_id),
    )
    prev = cur.fetchone()
    if not prev:
        return None
    cur.execute("SELECT ip, mac, hostname, status, rogue FROM nd_scan_results WHERE job_id=%s", (prev["id"],))
    rows = cur.fetchall()
    for r in rows:
        r["mac"] = (r.get("mac") or "").lower()
        r["status"] = r.get("status") or ("unknown" if r.get("rogue") else "lease")
    return rows


def jobs_to_prune(others, keep):
    """Pure: the ids of a subnet's OLD jobs to delete. `others` is every job of the subnet except the one
    running now, newest first, as [{"id", "status"}]. The running job is one of the `keep`; the newest
    `keep - 1` others stay, and so does the newest one that is `done`, always.

    1.2.1 kept the newest N by start time whatever their status. Two failed scans in a row (one /20
    timing out twice) pushed the last good scan out of the window; the next good scan then found no
    baseline, `new_unknowns(..., None)` called every unknown host new, and the whole subnet alerted at
    once. A job that is still queued or running is never pruned: its thread will write to the row."""
    kept = {j["id"] for j in others[: max(keep - 1, 0)]}
    for j in others:
        if j["status"] == "done":
            kept.add(j["id"])
            break
    return [j["id"] for j in others if j["id"] not in kept and j["status"] in ("done", "error")]


def _mark_job(db, job_id, status, error=None, hosts=0, unknown=0):
    with db.cursor() as cur:
        cur.execute(
            "UPDATE nd_scan_jobs SET status=%s, finished_at=NOW(), hosts_found=%s, rogue_count=%s, error=%s WHERE id=%s",
            (status, hosts, unknown, (error or "")[:255] or None, job_id),
        )
    db.commit()


_queue_lock = threading.Lock()


def _reserve_scan(subnet_id):
    """Reserve a scan job for `subnet_id`, or None when one is already queued or running.

    v1.2.3 (Q100 b) — `start_scan` and `_scheduled_tick` each did their OWN check-then-insert (a SELECT
    for a pending job, then, seeing none, an unconditional INSERT), with no lock around the pair —
    only `_scan_lock` wraps the RUN. A click racing the scheduler's own read (or two clicks close
    together) could both see 'nothing pending' and both insert a job, running two scans of the same
    subnet back to back. Both callers now go through this one function, serialised in-process by
    `_queue_lock`; the INSERT itself is also conditioned on no queued/running row existing for the
    subnet (`WHERE NOT EXISTS`), so it stays correct even without the lock, which only protects the
    in-process double-click case the lock is really for."""
    with _queue_lock:
        db = _get_db()
        try:
            with db.cursor() as cur:
                _expire_stale_running_jobs(cur)
                cur.execute(
                    "INSERT INTO nd_scan_jobs (subnet_id, status) "
                    "SELECT %s, 'queued' FROM DUAL WHERE NOT EXISTS ("
                    "SELECT 1 FROM nd_scan_jobs WHERE subnet_id=%s AND status IN ('queued', 'running'))",
                    (subnet_id, subnet_id),
                )
                job_id = cur.lastrowid if cur.rowcount else None
            db.commit()
            return job_id
        finally:
            db.close()


def _run_scan_job(subnet_id, cidr, job_id, trigger="manual"):
    """Run a job already queued as job_id (see _queue_scan_job) once the
    caller holds _scan_lock. Marks it 'running' — resetting started_at so
    the stale-job expiry clock starts at the actual run, not the queue
    time — then stores results in DB. Returns job_id."""
    db = _get_db()
    try:
        with db.cursor() as cur:
            cur.execute("UPDATE nd_scan_jobs SET status='running', started_at=NOW() WHERE id=%s", (job_id,))
        db.commit()

        result = _scan_subnet(cidr)
        if "error" in result:
            logger.error(f"Network Discovery: scan of {cidr} failed: {result['error']}")
            _mark_job(db, job_id, "error", result["error"])
            return job_id

        found = result["hosts"]
        ctx = _subnet_ctx(subnet_id, cidr)
        kea = _load_kea(subnet_id)
        ipam = _load_ipam(subnet_id)
        devices = _load_devices(sorted({h["mac"] for h in found if h.get("mac")}))
        hosts = classify(found, kea, ctx, ipam, devices, _load_known())
        unknown_count = sum(1 for h in hosts if h["status"] == "unknown")

        with db.cursor() as cur:
            previous = _previous_results(cur, subnet_id, job_id)
            prev_keys = None if previous is None else {host_key(r) for r in previous if r["status"] == "unknown"}
            fresh = new_unknowns(hosts, prev_keys)

            # Prune this subnet's history down to the newest _KEEP_JOBS jobs (this one
            # included) and the newest completed scan (jobs_to_prune) — one fixed statement per old job.
            cur.execute(
                "SELECT id, status FROM nd_scan_jobs WHERE subnet_id=%s AND id != %s ORDER BY started_at DESC, id DESC",
                (subnet_id, job_id),
            )
            for old_id in jobs_to_prune(cur.fetchall(), _KEEP_JOBS):
                cur.execute("DELETE FROM nd_scan_results WHERE job_id=%s", (old_id,))
                cur.execute("DELETE FROM nd_scan_jobs WHERE id=%s", (old_id,))
            for h in hosts:
                cur.execute(
                    """
                    INSERT INTO nd_scan_results (job_id, ip, mac, hostname, in_kea, rogue, status, label, vendor, device_type)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        job_id,
                        h["ip"],
                        h.get("mac", ""),
                        (h.get("hostname") or "")[
                            :255
                        ],  # VARCHAR(255): a longer rDNS name failed the INSERT and errored the scan
                        h["in_kea"],
                        h["rogue"],
                        h["status"],
                        (h.get("label") or "")[:200],
                        (h.get("vendor") or "")[:100],
                        (h.get("device_type") or "")[:30],
                    ),
                )
        db.commit()
        _mark_job(db, job_id, "done", None, len(hosts), unknown_count)

        if fresh:
            _alert_new_unknowns(subnet_id, fresh, unknown_count, trigger)
            _emit_new_unknowns(subnet_id, fresh)

    except Exception as e:
        logger.error(f"Network Discovery scan error: {e}")
        if job_id is not None:
            # 1.2.2: undo whatever this run had staged first. _mark_job commits the SAME connection, so
            # the prune's deletes (and any half-written result rows) used to be committed along with the
            # "error" status: a run that failed after pruning could delete the last good scan and leave
            # an error job with partial results.
            with contextlib.suppress(Exception):
                db.rollback()
            with contextlib.suppress(Exception):
                _mark_job(db, job_id, "error", "scan failed — see the Jen log")
    finally:
        db.close()

    return job_id


# v1.2.0 — Discovery now registers its own alert type through the plugin
# API (register_alert_type) instead of sending under Jen core's hard-coded
# "rogue_device". Jen keeps "rogue_device" itself as a legacy entry for
# installs whose channels already opted into it (see Jen's alerts.py).
_ROGUE_ALERT_TYPE = "network-discovery_rogue_device"


def _alert_new_unknowns(subnet_id, fresh, unknown_count, trigger):
    """`_ROGUE_ALERT_TYPE` (a channel opts into it under Settings → Alerts).
    subnet_id lets a subnet-scoped channel filter it like any other
    per-subnet alert."""
    try:
        from jen.plugin_api import send_alert

        subnet_name = _subnet_map().get(subnet_id, {}).get("name", str(subnet_id))
        lines = []
        for h in fresh[:10]:
            bits = [h["ip"]]
            if h.get("hostname"):
                bits.append(h["hostname"])
            if h.get("vendor"):
                bits.append(h["vendor"])
            if h.get("mac"):
                bits.append(h["mac"])
            lines.append("  • " + " · ".join(bits))
        listed = "\n".join(lines)
        if len(fresh) > 10:
            listed += f"\n  … and {len(fresh) - 10} more"
        send_alert(
            alert_type=_ROGUE_ALERT_TYPE,
            subnet_id=subnet_id,
            subject=f"⚠️ {len(fresh)} new unknown device(s) on {subnet_name}",
            body=(
                f"Network Discovery ({trigger} scan) found {len(fresh)} device(s) on {subnet_name} it can't "
                f"account for — not a Kea lease or reservation, not infrastructure, not an IPAM entry, not a "
                f"device Jen has seen, not marked known — that the previous scan hadn't seen "
                f"({unknown_count} unknown in total):\n{listed}"
            ),
        )
    except Exception as e:
        logger.warning(f"Network Discovery: could not send alert: {e}")


def _emit_new_unknowns(subnet_id, fresh):
    """emit() one `discovery.unknown` event per new unknown host (a core
    KINDS entry reserved for this release — jen/services/events.py) so
    the Timeline and Client Investigation see it, same as any other
    lease/reservation event."""
    try:
        from jen.plugin_api import emit

        subnet_name = _subnet_map().get(subnet_id, {}).get("name", str(subnet_id))
        for h in fresh:
            detail = f"new unknown host on {subnet_name}"
            if h.get("vendor"):
                detail += f" ({h['vendor']})"
            emit(
                "discovery.unknown",
                mac=h.get("mac") or None,
                ip=h.get("ip"),
                subnet_id=subnet_id,
                hostname=h.get("hostname") or None,
                detail=detail,
            )
    except Exception as e:
        logger.warning(f"Network Discovery: could not emit discovery.unknown: {e}")


def _expire_stale_running_jobs(cur):
    """A 'running' job older than _STALE_RUNNING_MINUTES is a leftover
    from a Jen restart mid-scan — its thread is gone. Without this the
    index shows it as 'Scanning…' forever and the poller never stops.
    v1.1.2 — covers 'queued' rows too: a job Jen queued but never got to
    start (Jen restarted before it reached the front of _scan_lock) would
    otherwise show "Queued" forever the same way.

    1.2.2 — a queued job is expired only when its thread is gone. The age is measured from the moment it
    was queued, and with several scans ahead of it on the lock a healthy queued job can be older than the
    window; expiring it made the duplicate check (queued+running) see nothing pending, so the next click
    queued a second scan of the same subnet. `_live_jobs` names the jobs whose thread is alive in this
    process; after a restart it is empty and the leftover expires as before."""
    cur.execute(
        "UPDATE nd_scan_jobs SET status='error', error='interrupted (Jen restarted mid-scan)', finished_at=NOW() "
        "WHERE status='running' AND started_at < NOW() - INTERVAL %s MINUTE",
        (_STALE_RUNNING_MINUTES,),
    )
    cur.execute(
        "SELECT id FROM nd_scan_jobs WHERE status='queued' AND started_at < NOW() - INTERVAL %s MINUTE",
        (_STALE_RUNNING_MINUTES,),
    )
    for row in cur.fetchall():
        if row["id"] in _live_jobs:
            continue
        cur.execute(
            "UPDATE nd_scan_jobs SET status='error', error='interrupted (Jen restarted mid-scan)', finished_at=NOW() "
            "WHERE id=%s AND status='queued'",
            (row["id"],),
        )


def _start_scan_thread(subnet_id, cidr, job_id, trigger="manual"):
    """Run an ALREADY-RESERVED job (`_reserve_scan`) in a background thread."""
    _live_jobs.add(job_id)

    def _bg():
        try:
            with _scan_lock:
                _run_scan_job(subnet_id, cidr, job_id, trigger)
        finally:
            _live_jobs.discard(job_id)

    threading.Thread(target=_bg, daemon=True).start()


# ── Scheduling (v1.1.0, Jen 5.30.0 register_periodic) ─────────────────────────


def _schedules():
    """{subnet_id: every_hours} for subnets with a schedule set."""
    out = {}
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute("SELECT subnet_id, every_hours FROM nd_settings WHERE every_hours > 0")
            for row in cur.fetchall():
                out[row["subnet_id"]] = int(row["every_hours"])
    except Exception as e:
        logger.warning(f"Network Discovery: could not read schedules: {e}")
    finally:
        if db:
            db.close()
    return out


def due_subnets(schedules, last_done, running, now):
    """Pure: subnet ids whose last completed scan is older than their
    interval (or never ran), excluding ones mid-scan."""
    due = []
    for sid, hours in schedules.items():
        if sid in running:
            continue
        last = last_done.get(sid)
        if last is None or last <= now - timedelta(hours=hours):
            due.append(sid)
    return due


def _scheduled_tick():
    """The periodic job: scan every subnet that's due, one after the
    other (the scan lock serialises them anyway)."""
    schedules = _schedules()
    if not schedules or not _nmap_available():
        return
    subnet_map = _subnet_map()
    last_done, running = {}, set()
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            _expire_stale_running_jobs(cur)
            for sid in schedules:
                cur.execute(
                    "SELECT status, finished_at FROM nd_scan_jobs WHERE subnet_id=%s ORDER BY started_at DESC, id DESC LIMIT 1",
                    (sid,),
                )
                row = cur.fetchone()
                # v1.1.2 — a queued-but-not-yet-running job counts the same
                # as running for scheduling purposes: it's already handled.
                if row and row["status"] in ("running", "queued"):
                    running.add(sid)
                elif row and row["status"] == "done" and row.get("finished_at"):
                    last_done[sid] = row["finished_at"].replace(tzinfo=timezone.utc)
        db.commit()
    except Exception as e:
        logger.warning(f"Network Discovery: schedule tick could not read job state: {e}")
        return
    finally:
        if db:
            db.close()
    for sid in due_subnets(schedules, last_done, running, datetime.now(timezone.utc)):
        info = subnet_map.get(sid)
        if not info or scan_scope_error(info["cidr"]):
            continue
        job_id = _reserve_scan(sid)
        if job_id is None:  # already queued or running (a click raced this tick)
            continue
        logger.info(f"Network Discovery: scheduled scan of {info['name']} ({info['cidr']})")
        _live_jobs.add(job_id)
        try:
            with _scan_lock:
                _run_scan_job(sid, info["cidr"], job_id, trigger="scheduled")
        finally:
            _live_jobs.discard(job_id)


# ── Routes ────────────────────────────────────────────────────────────────────


@bp.route("/")
@login_required
def index():
    subnet_map = _accessible_subnets()
    scan_summary = {}
    schedules = _schedules()
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            _expire_stale_running_jobs(cur)
            known = _load_known()
            for sid in subnet_map:
                cur.execute(
                    """
                    SELECT j.id, j.status, j.started_at, j.finished_at, j.hosts_found, j.rogue_count, j.error
                    FROM nd_scan_jobs j WHERE j.subnet_id=%s
                    ORDER BY j.started_at DESC, j.id DESC LIMIT 1
                    """,
                    (sid,),
                )
                row = cur.fetchone()
                if row and row["status"] == "done":
                    # v1.2.3 (Q100 a) — the stored rogue_count is a snapshot from scan time; a mark/forget
                    # elsewhere no longer updates it, so the card recomputes it live from the current list.
                    rows = apply_known(_load_results(cur, row["id"]), known)
                    row = dict(row)
                    row["hosts_found"] = len(rows)
                    row["rogue_count"] = sum(1 for r in rows if r["status"] == "unknown")
                scan_summary[sid] = row or {}
        db.commit()
    except Exception as e:
        logger.error(f"Network Discovery index error: {e}")
    finally:
        if db:
            db.close()

    return render_template(
        "network_discovery/index.html",
        subnet_map=subnet_map,
        scan_summary=scan_summary,
        schedules=schedules,
        schedule_choices=_SCHEDULE_CHOICES,
        scope_errors={sid: scan_scope_error(info["cidr"]) for sid, info in subnet_map.items()},
        scanner_ok=_nmap_available(),
        can_install_nmap=_can_install_nmap() and _is_superadmin(),
        is_superadmin=_is_superadmin(),
        plugin_id=PLUGIN_ID,
    )


@bp.route("/scan/<int:subnet_id>", methods=["POST"])
@login_required
def start_scan(subnet_id):
    if not _require_write():
        return redirect(url_for("network_discovery.index"))

    from jen.plugin_api import assert_subnet_access

    if not assert_subnet_access(subnet_id):
        return redirect(url_for("network_discovery.index"))

    subnet_map = _subnet_map()
    if subnet_id not in subnet_map:
        flash("Subnet not found.", "error")
        return redirect(url_for("network_discovery.index"))

    if not _nmap_available():
        flash(
            "nmap is not installed on the Jen host — install it from Settings → Plugins, or `sudo apt install nmap`.",
            "error",
        )
        return redirect(url_for("network_discovery.index"))

    cidr = subnet_map[subnet_id]["cidr"]
    scope = scan_scope_error(cidr)
    if scope:
        flash(scope, "error")
        return redirect(url_for("network_discovery.index"))

    # v1.2.3 (Q100 b) — reserve-and-check is now ONE atomic step, shared with the scheduler
    # (_reserve_scan); a job that only *looks* mid-scan because Jen restarted under it is expired
    # first, inside that same function, so it can't block the subnet forever.
    job_id = _reserve_scan(subnet_id)
    if job_id is None:
        flash(f"A scan of {subnet_map[subnet_id]['name']} is already in progress.", "warning")
        return redirect(url_for("network_discovery.index"))

    _start_scan_thread(subnet_id, cidr, job_id)
    flash(f"Scan started for {subnet_map[subnet_id]['name']}. Results will appear in a moment.", "success")
    return redirect(url_for("network_discovery.index"))


@bp.route("/schedule/<int:subnet_id>", methods=["POST"])
@login_required
def set_schedule(subnet_id):
    """v1.1.0 — per-subnet scan interval (hours; 0 = off). Superadmin: it
    starts unattended scanning."""
    if not _is_superadmin():
        flash("Only a superadmin can schedule scans.", "error")
        return redirect(url_for("network_discovery.index"))
    subnet_map = _subnet_map()
    if subnet_id not in subnet_map:
        flash("Subnet not found.", "error")
        return redirect(url_for("network_discovery.index"))
    raw = request.form.get("every_hours", "0").strip()
    hours = int(raw) if raw.isdigit() else -1
    if hours not in _SCHEDULE_CHOICES:
        flash("Pick one of the offered intervals.", "error")
        return redirect(url_for("network_discovery.index"))
    scope = scan_scope_error(subnet_map[subnet_id]["cidr"]) if hours else None
    if scope:
        flash(scope, "error")
        return redirect(url_for("network_discovery.index"))
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                "INSERT INTO nd_settings (subnet_id, every_hours) VALUES (%s, %s) "
                "ON DUPLICATE KEY UPDATE every_hours=VALUES(every_hours)",
                (subnet_id, hours),
            )
        db.commit()
        name = subnet_map[subnet_id]["name"]
        flash(f"{name}: scheduled scans {'off' if not hours else f'every {hours} h'}.", "success")
        try:
            from jen.plugin_api import audit

            audit("ND_SCHEDULE", name, f"subnet={subnet_id} every_hours={hours}")
        except Exception:
            pass
    except Exception as e:
        logger.error(f"Network Discovery: could not save schedule: {e}")
        flash("Could not save the schedule — is the plugin's database migration applied?", "error")
    finally:
        if db:
            db.close()
    return redirect(url_for("network_discovery.index"))


def _load_results(cur, job_id, known=None):
    cur.execute(
        """
        SELECT ip, mac, hostname, in_kea, rogue, status, label, vendor, device_type, discovered_at
        FROM nd_scan_results WHERE job_id=%s
        ORDER BY inet_aton(ip)
        """,
        (job_id,),
    )
    rows = cur.fetchall()
    for r in rows:
        r["mac"] = (r.get("mac") or "").lower()
        r["status"] = r.get("status") or ("unknown" if r.get("rogue") else "lease")
        r["label"] = r.get("label") or ""
        r["vendor"] = r.get("vendor") or ""
    # v1.2.3 (Q100 a) — every reader of stored results re-derives known/unknown live; `known=None` keeps
    # the raw scanned status for a caller that doesn't need it (none do any more, but the parameter stays
    # optional so a future caller is not forced to pay for a known-hosts read it has no use for).
    if known is not None:
        rows = apply_known(rows, known)
    return rows


@bp.route("/results/<int:subnet_id>")
@login_required
def results(subnet_id):
    from jen.plugin_api import assert_subnet_access

    if not assert_subnet_access(subnet_id):
        return redirect(url_for("network_discovery.index"))

    subnet_map = _subnet_map()
    if subnet_id not in subnet_map:
        flash("Subnet not found.", "error")
        return redirect(url_for("network_discovery.index"))

    job = None
    latest_job = None
    hosts = []
    appeared, gone = [], []
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                """
                SELECT id, status, started_at, finished_at, hosts_found, rogue_count, error
                FROM nd_scan_jobs WHERE subnet_id=%s
                ORDER BY started_at DESC, id DESC LIMIT 1
                """,
                (subnet_id,),
            )
            latest_job = cur.fetchone()
            job = latest_job
            if latest_job and latest_job["status"] != "done":
                # 1.2.2: the page shows the latest COMPLETED scan and a banner about the newer one. It used
                # to take the latest job of any status: for a failed or running one there are no rows, so
                # the table was empty and "what changed" listed every host of the previous scan as gone.
                cur.execute(
                    """
                    SELECT id, status, started_at, finished_at, hosts_found, rogue_count, error
                    FROM nd_scan_jobs WHERE subnet_id=%s AND status='done'
                    ORDER BY started_at DESC, id DESC LIMIT 1
                    """,
                    (subnet_id,),
                )
                job = cur.fetchone() or latest_job
            if job:
                hosts = _load_results(cur, job["id"], known=_load_known())
                previous = _previous_results(cur, subnet_id, job["id"])
                if previous is not None:
                    appeared, gone = delta(hosts, previous)
    except Exception as e:
        logger.error(f"Network Discovery results error: {e}")
        flash("Could not load scan results. Check the Jen log for details.", "error")
    finally:
        if db:
            db.close()

    counts = {s: sum(1 for h in hosts if h["status"] == s) for s in _STATUSES}
    ipam_installed = _ipam_installed()
    return render_template(
        "network_discovery/results.html",
        subnet_map=subnet_map,
        subnet_id=subnet_id,
        subnet=subnet_map.get(subnet_id, {}),
        job=job,
        newer_job=latest_job if latest_job and job and latest_job["id"] != job["id"] else None,
        can_change_known=_can_change_known(),
        hosts=hosts,
        counts=counts,
        statuses=_STATUSES,
        status_labels=_STATUS_LABELS,
        status_icons=_STATUS_ICONS,
        appeared=appeared,
        gone=gone,
        ipam_installed=ipam_installed,
    )


def _ipam_installed():
    try:
        from jen.plugin_api import installed_plugins

        return any(p.get("id") == "ipam" and p.get("enabled") for p in installed_plugins())
    except Exception:
        return False


@bp.route("/results/<int:subnet_id>/export")
@login_required
def export_results(subnet_id):
    from jen.plugin_api import assert_subnet_access

    if not assert_subnet_access(subnet_id):
        return redirect(url_for("network_discovery.index"))
    rows = []
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                "SELECT id FROM nd_scan_jobs WHERE subnet_id=%s AND status='done' ORDER BY started_at DESC, id DESC LIMIT 1",
                (subnet_id,),
            )
            job = cur.fetchone()
            if job:
                rows = _load_results(cur, job["id"], known=_load_known())
    except Exception as e:
        logger.error(f"Network Discovery export error: {e}")
    finally:
        if db:
            db.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ip", "hostname", "mac", "status", "label", "vendor", "device_type", "discovered_at"])
    for r in rows:
        writer.writerow(
            _safe_row(
                [
                    r["ip"],
                    r.get("hostname") or "",
                    r["mac"],
                    r["status"],
                    r["label"],
                    r["vendor"],
                    r.get("device_type") or "",
                    r["discovered_at"].strftime("%Y-%m-%d %H:%M") if r.get("discovered_at") else "",
                ]
            )
        )
    name = _subnet_map().get(subnet_id, {}).get("name", str(subnet_id))
    resp = make_response(output.getvalue())
    resp.headers["Content-Type"] = "text/csv"
    resp.headers["Content-Disposition"] = f"attachment; filename=discovery-{subnet_id}.csv"
    logger.info(f"Network Discovery: exported {len(rows)} rows for {name}")
    return resp


@bp.route("/known/<int:subnet_id>", methods=["POST"])
@login_required
def mark_known(subnet_id):
    """v1.1.0 — "I know this one": never alert on this MAC (or IP, when
    there's no MAC) again; shows as `known` on every future scan.
    `action=forget` removes it."""
    if not _require_write():
        return redirect(url_for("network_discovery.results", subnet_id=subnet_id))

    from jen.plugin_api import assert_subnet_access

    if not assert_subnet_access(subnet_id):
        return redirect(url_for("network_discovery.index"))
    if not _can_change_known():
        flash(
            "Only an administrator with access to every subnet can change the known-hosts list: it applies to every subnet.",
            "error",
        )
        return redirect(url_for("network_discovery.results", subnet_id=subnet_id))
    back = redirect(url_for("network_discovery.results", subnet_id=subnet_id))
    ip = request.form.get("ip", "").strip()
    mac = request.form.get("mac", "").strip().lower()
    note = request.form.get("note", "").strip()[:200]
    action = request.form.get("action", "add")
    try:
        if ip:
            ipaddress.IPv4Address(ip)
    except ValueError:
        flash("Invalid IP address.", "error")
        return back
    from jen.plugin_api import normalize_mac

    if mac and not normalize_mac(mac):
        flash("Invalid MAC address.", "error")
        return back
    if not mac and not ip:
        flash("Nothing to mark.", "error")
        return back
    key_mac, key_ip = (mac, "") if mac else ("", ip)
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            if action == "forget":
                cur.execute("DELETE FROM nd_known_hosts WHERE mac=%s AND ip=%s", (key_mac, key_ip))
            else:
                cur.execute(
                    "INSERT INTO nd_known_hosts (mac, ip, note, added_by) VALUES (%s, %s, %s, %s) "
                    "ON DUPLICATE KEY UPDATE note=VALUES(note), added_by=VALUES(added_by)",
                    (key_mac, key_ip, note, current_user.username),
                )
            # v1.2.3 (Q100 a) — nothing left to reflect into a stored job: every reader re-derives
            # known/unknown from this table live (apply_known), so the change is visible everywhere,
            # on every subnet, the moment this commits — not just the one job this used to UPDATE.
        db.commit()
        what = mac or ip
        flash(
            f"{what} {'forgotten — it will count as unknown again' if action == 'forget' else 'marked known — it will not alert again'}.",
            "success",
        )
        try:
            from jen.plugin_api import audit

            audit("ND_KNOWN_HOST", what, f"subnet={subnet_id} action={action} note={note}")
        except Exception:
            pass
    except Exception as e:
        logger.error(f"Network Discovery: could not update known hosts: {e}")
        flash("Could not save — is the plugin's database migration applied?", "error")
    finally:
        if db:
            db.close()
    return back


@bp.route("/api/scan-status/<int:subnet_id>")
@login_required
def api_scan_status(subnet_id):
    """Poll endpoint for scan progress."""
    from jen.plugin_api import subnet_or_404

    _subnet, refused = subnet_or_404(subnet_id)
    if refused:
        return refused
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                """
                SELECT id, status, started_at, finished_at, hosts_found, rogue_count, error
                FROM nd_scan_jobs WHERE subnet_id=%s
                ORDER BY started_at DESC, id DESC LIMIT 1
                """,
                (subnet_id,),
            )
            row = cur.fetchone()
        if row:
            return jsonify(
                {
                    "status": row["status"],
                    "hosts_found": row["hosts_found"],
                    "rogue_count": row["rogue_count"],
                    "error": row.get("error") or "",
                    "finished_at": row["finished_at"].isoformat() if row["finished_at"] else None,
                }
            )
        return jsonify({"status": "never"})
    except Exception as e:
        logger.error(f"Network Discovery scan-status error: {e}")
        return jsonify({"status": "error", "error": "Could not read scan status."})
    finally:
        if db:
            db.close()


# ── Search provider (v1.2.0, plugin API v3) ───────────────────────────────────


def _discovery_search(query, accessible_subnet_ids, all_subnets):
    """register_search_provider callback — a MAC, IP, hostname, label or
    vendor found in the most recent completed scan of a subnet. Jen
    re-filters by subnet_id itself afterward (the Q55 rule)."""
    q = (query or "").strip()
    if not q:
        return []
    from jen.plugin_api import like_pattern, search_scope

    # v1.2.3 (Q100) — the caller's own subnet scope is now IN the query, before its own LIMIT 20: it
    # used to take the newest 20 matches across every subnet and rely on Jen's own re-filter to drop the
    # ones the caller cannot see, so a restricted caller whose only match came after 20 matches from a
    # subnet they cannot see got nothing.
    scope = search_scope(accessible_subnet_ids, all_subnets, "j.subnet_id")
    if scope is None:
        return []
    scope_clause, scope_params = scope
    like = like_pattern(q)
    out = []
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            # 1.2.2: only each subnet's LATEST completed scan. The plugin keeps a few scans per subnet, and
            # the join used to search all of them, so a host that has since gone (or changed IP) was still
            # found, once per scan that saw it.
            cur.execute(
                f"""
                SELECT r.ip, r.mac, r.hostname, r.label, r.vendor, r.discovered_at, j.subnet_id
                FROM nd_scan_results r
                JOIN nd_scan_jobs j ON j.id = r.job_id
                WHERE j.status = 'done' AND {scope_clause}
                  AND j.id = (
                      SELECT j2.id FROM nd_scan_jobs j2
                      WHERE j2.subnet_id = j.subnet_id AND j2.status = 'done'
                      ORDER BY j2.started_at DESC, j2.id DESC LIMIT 1
                  )
                  AND (r.mac LIKE %s OR r.ip LIKE %s OR r.hostname LIKE %s OR r.label LIKE %s OR r.vendor LIKE %s)
                ORDER BY r.discovered_at DESC LIMIT 20
                """,  # nosec B608 - scope_clause is search_scope()'s own %s placeholders, values bound below
                (*scope_params, like, like, like, like, like),
            )
            for row in cur.fetchall():
                bits = [row["ip"]]
                if row.get("mac"):
                    bits.append(row["mac"])
                if row.get("discovered_at"):
                    bits.append("last seen " + row["discovered_at"].strftime("%Y-%m-%d %H:%M"))
                out.append(
                    {
                        "title": row.get("hostname") or row.get("label") or row["ip"],
                        "subtitle": " · ".join(bits),
                        "href": f"/network/discovery/results/{row['subnet_id']}",
                        "subnet_id": row["subnet_id"],
                    }
                )
    except Exception as e:
        logger.error(f"Network Discovery: search provider failed: {e}")
    finally:
        if db:
            db.close()
    return out


# ── Investigation provider (v1.3.0, Jen 5.68.0) ──────────────────────────────

_INVESTIGATION_MAX_ROWS = 5


def subject_addresses(subject):
    """Pure: the IPv4 addresses this client is known by - the one the page was opened on, its active leases and its
    reservations - each validated, de-duplicated and capped. A scan finds a host by address as often as by MAC."""
    seen = []
    candidates = [getattr(subject, "ip", "")]
    candidates += [r.get("ip") for r in (getattr(subject, "leases4", None) or []) if isinstance(r, dict)]
    candidates += [r.get("ip") for r in (getattr(subject, "reservations", None) or []) if isinstance(r, dict)]
    for raw in candidates:
        try:
            addr = str(ipaddress.IPv4Address(str(raw).strip()))
        except ValueError:
            continue
        if addr not in seen:
            seen.append(addr)
    return seen[:6]


def _when(value):
    if hasattr(value, "strftime"):
        return value.strftime("%Y-%m-%d %H:%M UTC")
    return str(value) if value else ""


def investigation_card(found):
    """Pure: the Investigation page's card from the rows the newest finished scan of each subnet holds for this client
    (status, vendor, device type, hostname and label seen, when found), or None when no scan has seen it. A host whose
    status is still `unknown` after the operator's known-hosts list was applied is a warn card: a scan found it on the
    network and nothing Jen knows accounts for it. The scan stores what it found, not the ports it probed, so none are shown."""
    if not found:
        return None
    rows, unknown = [], 0
    for r in found[:_INVESTIGATION_MAX_ROWS]:
        status = r.get("status") or ("unknown" if r.get("rogue") else "lease")
        if status == "unknown":
            unknown += 1
        what = [r["ip"], status]
        if r.get("vendor"):
            what.append(r["vendor"])
        if r.get("device_type"):
            what.append(r["device_type"])
        rows.append(
            {
                "label": f"Subnet {r['subnet_id']}",
                "value": " - ".join(what),
                "href": f"/network/discovery/results/{r['subnet_id']}",
            }
        )
        if r.get("hostname") or r.get("label"):
            rows.append({"label": "Name seen", "value": r.get("hostname") or r.get("label")})
        if r.get("discovered_at"):
            rows.append({"label": "Found by the scan at", "value": _when(r["discovered_at"])})
    first = found[0]
    summary = f"The newest scan of subnet {first['subnet_id']} found {first['ip']} ({first.get('status') or 'seen'})"
    if first.get("vendor"):
        summary += f", vendor {first['vendor']}"
    if len(found) > 1:
        summary += f"; {len(found) - 1} more result{'s' if len(found) > 2 else ''} in other scans"
    if unknown:
        summary += " - nothing Jen knows accounts for it"
    return {"summary": summary, "status": "warn" if unknown else "ok", "rows": rows}


def _scan_rows_for_client(mac, addresses, accessible_subnet_ids, all_subnets):
    """Each subnet's NEWEST finished scan's rows for this MAC or these addresses, inside the caller's own subnet scope - in
    the query, before its LIMIT (the same rule as the search provider). Known/unknown is re-derived from the list as it
    stands now, like every other reader of stored results."""
    from jen.plugin_api import in_placeholders, search_scope

    scope = search_scope(accessible_subnet_ids, all_subnets, "j.subnet_id")
    if scope is None:
        return []
    scope_clause, scope_params = scope
    identity, identity_params = [], []
    if mac:
        identity.append("r.mac=%s")
        identity_params.append(mac)
    if addresses:
        identity.append(f"r.ip IN ({in_placeholders(addresses)})")
        identity_params.extend(addresses)
    if not identity:
        return []
    db = None
    try:
        db = _get_db()
        with db.cursor() as cur:
            cur.execute(
                f"""
                SELECT r.ip, r.mac, r.hostname, r.status, r.rogue, r.label, r.vendor, r.device_type, r.discovered_at, j.subnet_id
                FROM nd_scan_results r
                JOIN nd_scan_jobs j ON j.id = r.job_id
                WHERE j.status = 'done' AND {scope_clause}
                  AND j.id = (
                      SELECT j2.id FROM nd_scan_jobs j2
                      WHERE j2.subnet_id = j.subnet_id AND j2.status = 'done'
                      ORDER BY j2.started_at DESC, j2.id DESC LIMIT 1
                  )
                  AND ({" OR ".join(identity)})
                ORDER BY r.discovered_at DESC LIMIT {_INVESTIGATION_MAX_ROWS}
                """,  # nosec B608 - scope_clause and the identity terms are fixed fragments with %s placeholders; every value is bound below
                (*scope_params, *identity_params),
            )
            rows = list(cur.fetchall())
    finally:
        if db:
            db.close()
    for r in rows:
        r["mac"] = (r.get("mac") or "").lower()
    return apply_known(rows, _load_known()) if rows else rows


def _investigate(subject, accessible_subnet_ids, all_subnets):
    """The Investigation page's card for the client Jen resolved: what the newest finished scan of each subnet found on its
    MAC or its addresses. Each row is judged on the subnet of the scan that found it, in the query, so a restricted caller
    never receives a row from a subnet outside the set Jen handed over."""
    from jen.plugin_api import normalize_mac

    mac = normalize_mac(getattr(subject, "mac", "") or "")
    card = investigation_card(
        _scan_rows_for_client(mac, subject_addresses(subject), accessible_subnet_ids, all_subnets)
    )
    if card is not None:
        card["href"] = "/network/discovery"
    return card


def register(app):
    app.register_blueprint(bp)
    # v1.1.0 — scheduled scans through Jen's periodic-job hook (5.30.0).
    # Registration only; nothing starts here (create_app must stay pure).
    try:
        from jen.plugin_api import register_periodic

        register_periodic(PLUGIN_ID, "scheduled-scans", _scheduled_tick, _SCHEDULE_TICK_MINUTES)
    except Exception as e:
        logger.warning(f"Network Discovery: scheduled scans unavailable on this Jen: {e}")

    from jen.plugin_api import register_alert_type, register_investigation_provider, register_search_provider

    register_alert_type(
        PLUGIN_ID,
        _ROGUE_ALERT_TYPE,
        label="Rogue Device",
        icon="siren",
        default_template="🚨 <b>{subject}</b>\n{body}",
    )
    register_search_provider(PLUGIN_ID, title="Network Discovery", fn=_discovery_search)
    register_investigation_provider(PLUGIN_ID, title="Network Discovery", fn=_investigate)

    logger.info("Network Discovery plugin registered")
